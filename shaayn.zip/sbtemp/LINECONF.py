import random

"""
FIX LINE BOT FILE BY KINGBOTS
"""

db = {
    "CHROMEOS": {
        "app_version": ["2.4.0", "2.4.1", "2.4.2", "2.4.3","2.4.4", "2.4.5","2.4.6", "2.4.7","2.4.8", "2.4.9", "2.5.0"],
        "sys_version": ["1"],
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{} Safari/537.36"
    },
    "DESKTOPWIN": {
        "app_version": ["7.7.0", "7.5.0", "7.4.1", "7.4.0", "7.3.1", "7.3.0"],
        "sys_version": ["10.0.{}", "8.1.{}", "8.0.{}", "7.0.{}"],
        "user_agent": "Line/{} (Windows NT {}; Win64; x64)"
    },
    "DESKTOPMAC": {
        "app_version": ["7.7.0", "7.5.0", "7.4.1", "7.4.0", "7.3.1", "7.3.0"],
        "sys_version": ["11.5.2", "11.5.1", "11.5.0", "11.4.0", "11.3.1", "11.3.0", "11.2.3", "11.2.2", "11.2.1", "11.2.0", "11.1.0", "11.0.1", "11.0.0", "10.15.7", "10.15.6", "10.15.5", "10.15.4", "10.15.3", "10.15.2", "10.15.1", "10.15.0", "10.14.6", "10.14.5", "10.14.4", "10.14.3", "10.14.2", "10.14.1", "10.14.0"],
        "user_agent": "Line/{} (Intel Mac OS X {})"
    },
    "IOSIPAD": {
        "app_version": ["11.12.0", "11.13.0", "11.15.0", "11.16.0", "11.17.0", "11.18.0", "11.19.0", "11.20.0", "11.22.0", "12.0.0"],
        "sys_version": ["14.8.0", "14.7.1", "14.7.0", "14.6.0", "14.5.1", "14.5.0", "14.4.2", "14.4.1", "14.4.0", "14.3.0", "14.2.1", "14.2.0", "14.0.1", "14.0.0"],
        "user_agent": "Line/{} (iPad; U; CPU iPhone OS {} like Mac OS X; en_US)"
    },
    "IOS": {
        "app_version": ["11.12.0", "11.13.0", "11.15.0", "11.16.0", "11.17.0", "11.18.0", "11.19.0", "11.20.0", "11.22.0", "12.0.0"],
        "sys_version": ["14.8.0", "14.7.1", "14.7.0", "14.6.0", "14.5.1", "14.5.0", "14.4.2", "14.4.1", "14.4.0", "14.3.0", "14.2.1", "14.2.0", "14.0.1", "14.0.0"],
        "user_agent": "Line/{} (iPhone; CPU iPhone OS {})"
    },
    "ANDROID": {
        "app_version": ["11.12.0", "11.13.0", "11.15.0", "11.16.0", "11.17.0", "11.18.0", "11.19.0", "11.20.0", "11.22.0", "12.0.0"],
        "sys_version": ["11.0.0", "10.0.0", "9.0.0", "8.1.0", "8.0.0", "7.1.2", "7.1.1", "7.1.0", "7.0.0", "6.0.1", "6.0.0"],
        "user_agent": "Line/{} (Android {}; {})"
    }
}

def line_config_random(apps):
    global db
    apps = apps.split("\t")[0].upper()
    if apps == "CHROMEOS":
        return {
            "X-Line-Application": f"{apps}\t{random.choice(db[apps]['app_version'])}\tChrome_OS\t1",
            "User-Agent": db[apps]['user_agent'].format(f"{random.randint(80,97)}.0.{random.randint(1000,10000)}.{random.randint(1,100)}")
        }

    elif apps == "DESKTOPWIN":
        device = "DESKTOP-"+"".join(random.choice("ACDEFGHIJKLMNOPQRSTUVWXYZ012345689") for x in range(7))
        app_version = random.choice(db[apps]['app_version'])
        sys_version = random.choice(db[apps]['sys_version']).format(random.randint(1000,2400))
        return {
            "X-Line-Application": f"{apps}\t{app_version}\t{device}\t{sys_version}",
            "User-Agent": db[apps]['user_agent'].format(app_version, sys_version)
        }

    elif apps == "DESKTOPMAC":
        device = "".join(random.choice("acdefghijklmnopqrstuvwxyz") for x in range(random.randint(4,8))).title() + "-Macbook-Pro"
        app_version = random.choice(db[apps]['app_version'])
        sys_version = random.choice(db[apps]['sys_version'])
        return {
            "X-Line-Application": f"{apps}\t{app_version}\t{device}\t{sys_version}",
            "User-Agent": db[apps]['user_agent'].format(app_version, sys_version)
        }

    elif apps == "IOSIPAD":
        app_version = random.choice(db[apps]['app_version'])
        sys_version = random.choice(db[apps]['sys_version'])
        return {
            "X-Line-Application": f"{apps}\t{app_version}\tiPad\t{sys_version}",
            "User-Agent": db[apps]['user_agent'].format(app_version, sys_version.replace('.','_'))
        }

    elif apps == "IOS":
        app_version = random.choice(db[apps]['app_version'])
        sys_version = random.choice(db[apps]['sys_version'])
        return {
            "X-Line-Application": f"{apps}\t{app_version}\tiOS\t{sys_version}",
            "User-Agent": db[apps]['user_agent'].format(app_version, sys_version.replace('.','_'))
        }

    elif apps == "ANDROID":
        device = f"CPH{random.randint(1,2)}" + "".join(random.choice("1234567890") for i in range(3))
        app_version = random.choice(db[apps]['app_version'])
        sys_version = random.choice(db[apps]['sys_version'])
        return {
            "X-Line-Application": f"{apps}\t{app_version}\tAndroid OS\t{sys_version}",
            "User-Agent": db[apps]['user_agent'].format(app_version, sys_version, device)
        }

    raise Exception("App Name Not Found\nUsage: CHROMEOS / DESKTOPWIN / DESKTOPMAC / IOSIPAD / IOS / ANDROID")